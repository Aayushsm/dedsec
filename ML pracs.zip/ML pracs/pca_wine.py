import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# 1. Load the dataset
# Adjust the path if necessary depending on where you run the script
df = pd.read_csv('Wine.csv')

# The dataset usually has the target variable in 'Customer_Segment' 
# or similar column. Let's separate features and target.
# Looking at the dataset, the last column is 'Customer_Segment'.
X = df.drop('Customer_Segment', axis=1)
y = df['Customer_Segment']

# 2. Standardize the data
# PCA is highly sensitive to the scaling of the data, so we must standardize it
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 3. Apply PCA
# We want to reduce the data to 2 principal components to easily visualize it
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)

# Create a new DataFrame with the principal components
pca_df = pd.DataFrame(data=X_pca, columns=['Principal Component 1', 'Principal Component 2'])

# Concatenate the target variable to the PCA DataFrame
pca_df = pd.concat([pca_df, y], axis=1)

# 4. Print the explained variance ratio
# This tells us how much information (variance) is attributed to each of the principal components
explained_variance = pca.explained_variance_ratio_
print(f"Explained variance by PC1: {explained_variance[0]:.4f}")
print(f"Explained variance by PC2: {explained_variance[1]:.4f}")
print(f"Total variance explained by 2 components: {sum(explained_variance):.4f}")

# 5. Plot the Principal Components
plt.figure(figsize=(10, 6))
sns.scatterplot(
    x='Principal Component 1', 
    y='Principal Component 2', 
    hue='Customer_Segment', 
    palette='viridis', 
    data=pca_df,
    s=100,
    alpha=0.8
)

plt.title('PCA of Wine Dataset')
plt.xlabel(f'Principal Component 1 ({explained_variance[0]*100:.2f}%)')
plt.ylabel(f'Principal Component 2 ({explained_variance[1]*100:.2f}%)')
plt.legend(title='Wine Class')
plt.grid(True)
plt.tight_layout()

# Save the plot as an image
# plt.savefig('pca_wine_plot.png')
# print("\nPlot saved as 'pca_wine_plot.png'")

# Display the plot (commented out to prevent hanging in headless environment)
plt.show()
