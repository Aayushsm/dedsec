#include <iostream>
using namespace std;

int main() {
    int cidr;
    int mask[4] = {0};

    cout << "Enter CIDR: ";
    cin >> cidr;

    for (int i = 0; i < 4; i++) {
        if (cidr >= 8) {
            mask[i] = 255;
            cidr -= 8;
        } else {
            mask[i] = 256 - (1 << (8 - cidr));
            cidr = 0;
        }
    }

    cout << "Subnet Mask: ";
    for (int i = 0; i < 4; i++) {
        cout << mask[i];
        if (i < 3) cout << ".";
    }
    cout << endl;

    return 0;
}