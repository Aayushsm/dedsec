#include<iostream>
#include <vector>
#include <climits>
using namespace std;
int minDistance(vector<int>& dist, vector<bool>& visited, int n) {
   int min = INT_MAX, min_index = -1;
   for (int v = 0; v < n; v++) {
       if (!visited[v] && dist[v] <= min) {
           min = dist[v];
           min_index = v;
       }
   }
   return min_index;
}

void dijkstra(vector<vector<int>>& graph, int src, int n) {
   vector<int> dist(n, INT_MAX); 
   vector<bool> visited(n, false);
   dist[src] = 0;
for (int count = 0; count < n - 1; count++) {
       int u = minDistance(dist, visited, n);
       if (u == -1) break;  
       visited[u] = true;
for (int v = 0; v < n; v++) {

           if (!visited[v] && graph[u][v] && dist[u] != INT_MAX
               && dist[u] + graph[u][v] < dist[v]) {
               dist[v] = dist[u] + graph[u][v];
           }
       }
}

   cout << "\nRouting table for router " << char(src + 'A') << ":\n";
   cout << "Destination\tCost\n";
   for (int i = 0; i < n; i++) {
       if (i != src) {
           cout << "Router " << char(i + 'A') << "\t\t";
           if (dist[i] == INT_MAX)
               cout << "INF" << endl;
           else
               cout << dist[i] << endl;
       }
   }
}
int main() {
   int n;
   cout << "Enter number of routers: ";
   cin >> n;
 
   vector<vector<int>> graph(n, vector<int>(n));
   cout << "\nEnter cost matrix (0 for self, INF as 999):\n";
   for (int i = 0; i < n; i++) {
       for (int j = 0; j < n; j++) {
           cin >> graph[i][j];
           if (graph[i][j] == 999) 
               graph[i][j] = 0;
       }
   }

   for (int i = 0; i < n; i++) {
       dijkstra(graph, i, n);
   }
return 0;
}
 