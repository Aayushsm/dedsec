#include <iostream>
#include <string>
#include <cstring>
#include <arpa/inet.h>  
#include <netdb.h>      
#include <netinet/in.h>
#include <sys/socket.h>
 
bool isValidIP(const std::string& ip) {
   struct sockaddr_in sa;
   int result = inet_pton(AF_INET, ip.c_str(), &(sa.sin_addr));
   if (result == 1) return true;
   struct sockaddr_in6 sa6;
   result = inet_pton(AF_INET6, ip.c_str(), &(sa6.sin6_addr));
   return result == 1;
}
 
int main() {
   std::string input;
   std::cout << "Enter IP address or domain name: ";
   std::getline(std::cin, input);
 
   if (isValidIP(input)) {
       // Reverse lookup: IP -> domain name
       struct in_addr addr;
       if (inet_pton(AF_INET, input.c_str(), &addr) <= 0) {
           std::cerr << "Invalid IP address format.\n";
           return 1;
       }
       struct hostent* host = gethostbyaddr(&addr, sizeof(addr), AF_INET);
       if (host == nullptr) {
           std::cerr << "Host not found for IP: " << input << "\n";
           return 1;
       }
       std::cout << "Domain name for IP " << input << " is: " << host->h_name << "\n";
   }
   else {
       struct hostent* host = gethostbyname(input.c_str());
       if (host == nullptr) {
           std::cerr << "Host not found for domain: " << input << "\n";
           return 1;
       }
       char ipStr[INET_ADDRSTRLEN];
       struct in_addr** addr_list = (struct in_addr**)host->h_addr_list;
       if (addr_list[0] != nullptr) {
           inet_ntop(AF_INET, addr_list[0], ipStr, sizeof(ipStr));
       std::cout << "IP address for domain " << input << " is: " << ipStr << "\n";
       } else {
           std::cerr << "No IP address found for domain: " << input << "\n";
           return 1;
       }
   }
   return 0;
}
 