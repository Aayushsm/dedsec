# ----- Create adjacency matrix -----
def create_matrix(n, edges):
    matrix = [[0]*n for _ in range(n)]
    for u, v in edges:
        matrix[u][v] = 1
        matrix[v][u] = 1   # undirected graph
    return matrix

# ----- DFS (recursive) -----
def dfs(matrix, node, visited):
    visited[node] = True
    print(node, end=" ")
    for neighbor in range(len(matrix)):
        if matrix[node][neighbor] == 1 and not visited[neighbor]:
            dfs(matrix, neighbor, visited)

# ----- BFS (recursive) -----
def bfs_recursive(matrix, queue, visited):
    if not queue:   # base case
        return
    
    node = queue.pop(0)
    if not visited[node]:
        print(node, end=" ")
        visited[node] = True
        
        # enqueue all unvisited neighbors
        for neighbor in range(len(matrix)):
            if matrix[node][neighbor] == 1 and not visited[neighbor]:
                queue.append(neighbor)

    # recursive call
    bfs_recursive(matrix, queue, visited)

# ----- MAIN -----
n = int(input("Enter number of vertices: "))
m = int(input("Enter number of edges: "))

edges = []
print("Enter edges (u v):")
for _ in range(m):
    u, v = map(int, input().split())
    edges.append((u, v))

matrix = create_matrix(n, edges)

print("\nDFS Traversal:")
visited_dfs = [False]*n
dfs(matrix, 0, visited_dfs)

print("\nBFS Traversal:")
visited_bfs = [False]*n
bfs_recursive(matrix, [0], visited_bfs)