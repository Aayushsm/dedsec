import heapq, copy

# ---- Manhattan distance heuristic ----
def heuristic(state, goal):
    dist = 0
    for i in range(3):
        for j in range(3):
            val = state[i][j]
            if val != 0:
                x, y = divmod(goal.index(val), 3)  # goal pos of tile
                dist += abs(x - i) + abs(y - j)
    return dist

# ---- Find empty tile ----
def find_empty(state):
    for i in range(3):
        for j in range(3):
            if state[i][j] == 0:
                return (i, j)

# ---- Generate child states ----
def neighbors(state, empty):
    children = []
    x, y = empty
    moves = [(-1,0),(1,0),(0,-1),(0,1)]  # up,down,left,right
    for dx, dy in moves:
        nx, ny = x+dx, y+dy
        if 0 <= nx < 3 and 0 <= ny < 3:
            new_state = copy.deepcopy(state)
            # swap empty with neighbor
            new_state[x][y], new_state[nx][ny] = new_state[nx][ny], new_state[x][y]
            children.append((new_state, (nx, ny)))
    return children

# ---- A* Algorithm ----
def a_star(start, goal):
    goal_flat = [num for row in goal for num in row]
    g = 0
    f = g + heuristic(start, goal_flat)
    
    heap = []
    heapq.heappush(heap, (f, g, start, find_empty(start)))
    visited = set()

    step = 0
    while heap:
        f, g, state, empty = heapq.heappop(heap)
        state_tuple = tuple(map(tuple, state))
        
        if state_tuple in visited:
            continue
        visited.add(state_tuple)

        print(f"Step {step}, g = {g}, f = {f}")
        for row in state:
            print(row)
        print()
        step += 1

        if state == goal:
            print("Goal reached!")
            return

        # expand neighbors
        for child, empty2 in neighbors(state, empty):
            g_new = g + 1
            f_new = g_new + heuristic(child, goal_flat)
            heapq.heappush(heap, (f_new, g_new, child, empty2))

# ---- MAIN ----
print("Enter initial 3x3 state (use 0 for blank):")
start = [list(map(int, input().split())) for _ in range(3)]
goal = [[1,2,3],[4,5,6],[7,8,0]]

print("\nStarting A* Search...\n")
a_star(start, goal)