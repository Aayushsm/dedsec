class Sack:
    def __init__(self, item_id, value, weight):
        self.item_id = item_id
        self.value = value
        self.weight = weight


def knap_sack(sacks, max_weight):
    sacks.sort(key=lambda x: x.value, reverse=True)
    curr_weight = max_weight
    total_value = 0
    count_sacks = 0

    for sack in sacks:
        if sack.weight <= curr_weight:
            curr_weight -= sack.weight
            total_value += sack.value
            count_sacks += 1
        elif curr_weight != 0:
            total_value += (sack.value * curr_weight / sack.weight)
            count_sacks += 1
            break
        else:
            break

    print(f"Total sacks Scheduled: {count_sacks}")
    print(f"Total value: {total_value}")


def main():
    max_weight = int(input("Enter weight of item: "))
    n = int(input("Enter no of sacks: "))
    sacks = []

    for i in range(n):
        print(f"\nEnter details for item {i+1}:")
        item_id = int(input("Item ID: "))
        value = int(input("Value: "))
        weight = int(input("Weight: "))
        sacks.append(Sack(item_id, value, weight))

    knap_sack(sacks, max_weight)


if __name__ == "__main__":
    main()