# Salon appointment booking bot

responses = {
    "hello": "Hello {user}! How can I assist you today?",
    "hi": "Hi there {user}! What can I help you with?",
    "appointment": "What service would you like to book an appointment for?",
    "book": "What service would you like to book an appointment for?",
    "schedule": "What service would you like to book an appointment for?",
    "service": "We offer cut, color, and style. Which one are you interested in?",
    "cut": "A 'cut' appointment is available.",
    "color": "A 'color' appointment is available.",
    "style": "A 'style' appointment is available.",
    "thanks": "You're welcome {user}! Is there anything else?",
    "thank you": "My pleasure {user}!",
    "bye": "Goodbye {user}! Have a great day.",
    "exit": "Goodbye {user}! Have a great day.",
    "yes": "Great! Your appointment is confirmed.",
    "no": "Okay, let's start over. What can I help you with?",
}

current_topic = None
service_choice = None
expecting_datetime = False
expecting_confirmation = False
booked_appointments = []

print("Trinity: Welcome to the Salon Booking Bot!")
user = input("Enter your name: ")

while True:
    user_input = input(user + ": ").lower()

    if user_input in ["bye", "exit"]:
        print("Trinity: Goodbye! Have a great day " + user + ".")
        break

    if expecting_confirmation:
        if "yes" in user_input:
            booked_appointments.append(f"{service_choice} on {datetime_input}")
            print(f"Trinity: {responses['yes']} You have booked a {service_choice} on {datetime_input}.")
        elif "no" in user_input:
            print(f"Trinity: {responses['no']}")
        else:
            print("Trinity: Please confirm with 'yes' or 'no'.")
            continue
        expecting_confirmation = False
        service_choice = None
        datetime_input = None
        continue

    if expecting_datetime:
        datetime_input = user_input
        print(f"Trinity: You want a {service_choice} on {datetime_input}. Confirm? (yes/no)")
        expecting_datetime = False
        expecting_confirmation = True
        continue

    matched = False
    for keyword, response in responses.items():
        if keyword in user_input:
            matched = True
            print("Trinity: ", response.format(user=user))
            current_topic = keyword
            if current_topic in ["cut", "color", "style"]:
                print("Trinity: What is your preferred day and time for the", current_topic, "?")
                service_choice = current_topic
                expecting_datetime = True
                current_topic = None
            break

    if not matched:
        if current_topic in ["cut", "color", "style"]:
            print("Trinity: What is your preferred day and time for the", current_topic, "?")
            service_choice = current_topic
            expecting_datetime = True
            current_topic = None
        else:
            print("Trinity: Sorry " + user + ", I don't understand that. You can ask about 'service' or say 'bye' to leave.")
