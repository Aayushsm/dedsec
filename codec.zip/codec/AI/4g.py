class Job:
    def __init__(self, job_id, deadline, profit):
        self.job_id = job_id
        self.deadline = deadline
        self.profit = profit


def job_scheduling(jobs):
    jobs.sort(key=lambda x: x.profit, reverse=True)
    max_deadline = max(job.deadline for job in jobs)
    result = [-1] * (max_deadline + 1)
    count_jobs = 0
    total_profit = 0

    for job in jobs:
        for slot in range(job.deadline, 0, -1):
            if result[slot] == -1:
                result[slot] = job.job_id
                count_jobs += 1
                total_profit += job.profit
                break

    scheduled_jobs = [job_id for job_id in result if job_id != -1]
    print(f"\nScheduled Jobs: {scheduled_jobs}")
    print(f"Total Jobs Scheduled: {count_jobs}")
    print(f"Total Profit: {total_profit}")


def main():
    n = int(input("Enter number of jobs: "))
    jobs = []

    for i in range(n):
        print(f"\nEnter details for Job {i+1}:")
        job_id = int(input("Job ID: "))
        profit = int(input("Profit: "))
        deadline = int(input("Deadline: "))
        jobs.append(Job(job_id, deadline, profit))

    job_scheduling(jobs)


if __name__ == "__main__":
    main()