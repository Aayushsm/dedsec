from random import choice
from math import inf

board  = [[0]*3 for _ in range(3)]

def Gameboard(board):
    chars = {1: 'X', -1: 'O', 0: ' '}
    for row in board:
        print("".join(f"| {chars[val]} |" for val in row))
        print("---------------")
    print("===============")

def Clearboard(board):
    for x in range(3):
        for y in range(3):
            board[x][y] = 0

def winningPlayer(board, player):
    conditions = [
        [board[0][0], board[0][1], board[0][2]],  # row 1
        [board[1][0], board[1][1], board[1][2]],  # row 2
        [board[2][0], board[2][1], board[2][2]],  # row 3
        [board[0][0], board[1][0], board[2][0]],  # col 1
        [board[0][1], board[1][1], board[2][1]],  # col 2
        [board[0][2], board[1][2], board[2][2]],  # col 3
        [board[0][0], board[1][1], board[2][2]],  # main diagonal
        [board[0][2], board[1][1], board[2][0]]   # anti diagonal
    ]
    return [player, player, player] in conditions

def gameWon(board): 
    return winningPlayer(board, 1) or winningPlayer(board, -1)

def printResult(board):
    if winningPlayer(board, 1): print("X has won!\n")
    elif winningPlayer(board, -1): print("O's have won!\n")
    else: print("Draw\n")

def blanks(board):
    return [(x, y) for x in range(3) for y in range(3) if board[x][y]==0]


def boardFull(board):
    return not blanks(board)

def setMove(board, x, y, p): 
    board[x][y] = p

def playerMove(board):
    moves = {i+1: (i//3, i%3) for i in range(9)}
    while True:
        try:
            move = int(input("Enter a number (1-9): "))
            if move not in moves or moves[move] not in blanks(board):
                print("Invalid Move! Try again!")
                continue
            setMove(board, *moves[move], 1)
            Gameboard(board)
            break
        except ValueError:
            print("Enter a number!")

def getScore(board):
    return 10 if winningPlayer(board, 1) else -10 if winningPlayer(board, -1) else 0

def alphabeta(board, depth, alpha, beta, player):
    if depth == 0 or gameWon(board):
        return -1, -1, getScore(board)

    row = col = -1
    for x,y in blanks(board):
        setMove(board, x, y, player)
        _, _, score = alphabeta(board, depth-1, alpha, beta, -player)
        setMove(board, x, y, 0)

        if player == 1 and score > alpha:
            alpha, row, col = score, x, y
        elif player == -1 and score < beta:
            beta, row, col = score, x, y

        if alpha >= beta:  # pruning
            break

    return (row, col, alpha) if player == 1 else (row, col, beta)

def bestMove(board, player):
    bestScore = -inf if player == 1 else inf
    move = (-1, -1)

    for x, y in blanks(board):
        setMove(board, x, y, player)
        _, _, score = alphabeta(board, len(blanks(board)), -inf, inf, -player)
        setMove(board, x, y, 0)

        if player == 1 and score > bestScore:
            bestScore, move = score, (x, y)
        elif player == -1 and score < bestScore:
            bestScore, move = score, (x, y)

    return move


def compMove(board, player):
    if len(blanks(board)) == 9:
        setMove(board, choice([0,1,2]), choice([0,1,2]), player)
    else:
        x, y, _ = alphabeta(board, len(blanks(board)), -inf, inf, player)
        setMove(board, x, y, player)
    Gameboard(board)

def makeMove(board, player, mode):
    if mode==1: playerMove(board) if player==1 else compMove(board, -1)
    else:       compMove(board, player)

def pvc():
    while True:
        try:
            order = int(input("Enter to play 1st or 2nd: "))
            if order in (1,2): break
            print("Please pick 1 or 2")
        except ValueError: print("Enter a number!")

    Clearboard(board)
    currentPlayer = 1 if order==1 else -1
    while not (boardFull(board) or gameWon(board)):
        makeMove(board, currentPlayer, 1)
        currentPlayer *= -1
    printResult(board)
# Driver
print("=================================================")
print("TIC-TAC-TOE using ALPHA-BETA Pruning")
print("=================================================")
pvc()
