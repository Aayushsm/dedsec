import pandas as pd

# Create the dataset
data = {
    "Math_Score": [65, 70, 72, 68, 75, 80, 60, 78, 66, 74],
    "Reading_Score": [78, 82, 88, 75, 90, 95, 77, 92, 85, 89],
    "Writing_Score": [62, 68, 70, 65, 74, 80, 60, 76, 69, 72],
    "Placement_Score": [80, 85, 90, 78, 95, 100, 76, 96, 88, 93],
    "Club_Join_Date": [2018, 2019, 2019, 2018, 2020, 2021, 2018, 2021, 2020, 2021],
    "Placement_Offer_Count": [1, 2, 2, 1, 3, 4, 0, 3, 2, 3]
}

df = pd.DataFrame(data)

# Save to CSV
file_path = "Students_Performance.csv"
df.to_csv(file_path, index=False)

file_path