a = [1,2,3]
b = [4,5,6]
print(a)
c = a.extend(b)
d = a.append(b)
print(a)
print(a)