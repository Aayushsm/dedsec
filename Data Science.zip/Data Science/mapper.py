#!/usr/bin/env python3
import sys

for line in sys.stdin:
    line = line.strip()
    words = line.split()
    
    if len(words) > 1:
        log_type = words[1]
        print(f"{log_type}\t1")